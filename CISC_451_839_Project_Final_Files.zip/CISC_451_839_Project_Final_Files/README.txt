Breakdown of files and executions for instruction:

Within this zip file, there exists:

1. A final project report (CISC_451_839_Project_Final_Report.pdf)
2. The main dataset (h1n1_flu_main_dataset.csv)
3. The imputed dataset (imputed_data_h1n1_flu.csv)
4. A main .ipynb notebook that can be loaded into to Google Colab along with the above 2 .csv files.
5. Another .ipynb notebook that contains the K-NN imputation code that uses the main dataset for imputation (can take 3+ hours).

To replicate, upload the main dataset and the imputed one with the attached CISC_451_839_Final_Project_Code.ipynb file to Colab or a suitable environment of choice. The .csv files can be uploaded to the local runtime or to a particular Google Drive location which can then be mounted. Everything can be executed in one go after setting the right paths to the data (for the main and imputed data files).


